/************* cd_ls_pwd.c file **************/

/**** globals defined in main.c file ****/
extern MINODE minode[NMINODE];
extern MINODE *root;
extern PROC   proc[NPROC], *running;
extern char   gpath[256];
extern char   *name[64];
extern int    n;
extern int fd, dev;
extern int nblocks, ninodes, bmap, imap, inode_start;
extern char line[256], cmd[32], pathname[256];

#define OWNER  000700
#define GROUP  000070
#define OTHER  000007

change_dir()
{
  printf("chage_dir(): to be constructed\n");
}

void ls_dir(char *dname)
{
  char buf[BLKSIZE], temp[256];
  DIR *dir, *dp;
  int ino = getino(dname);
  MINODE *mip = iget(dev, ino);
  get_block(dev, mip->INODE.i_block[0], buf);

  dp = (DIR *)buf;
  char *cp = dp;

  while(cp < buf + BLKSIZE){
    strncpy(temp, dp->name, dp->name_len);
    temp[dp->name_len] = 0;

    ls_file(dp->inode, temp);

    cp += dp->rec_len;
    dp = (DIR *)cp;
  }
}

void ls_file(int ino, char *name)
{
  //printf("NAME:%s, INODE#:%d\n",name,ino);
  MINODE *mip = iget(dev, ino);
  INODE *ip = &(mip->INODE);
  if (S_ISDIR(ip->i_mode))
    putchar('d');
  else if (S_ISREG(ip->i_mode))
    putchar('-');
  else if (S_ISLNK(ip->i_mode))
    putchar('l');
  for(int i = 8; i >=0; i--)
  {
    if (ip->i_mode & (1 << i))
      putchar('r');
    else putchar('-');
    i--;
    if (ip->i_mode & (1 << i))
      putchar('w');
    else putchar('-');
    i--;
    if (ip->i_mode & (1 << i))
      putchar('x');
    else putchar('-');
  }
  printf("%3d ", ip->i_links_count);
  printf("%5d %5d ", ip->i_gid, ip->i_uid);
  printf("%10d ", ip->i_size);
  printf("%.19s ", ctime(&ip->i_mtime));
  printf("%s\n", name);
}

int list_file()
{
  ls_dir(pathname);
}


int pwd(MINODE *wd)
{
  printf("pwd(): yet to be done by YOU\n");
}



